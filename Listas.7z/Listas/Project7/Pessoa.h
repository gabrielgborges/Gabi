#pragma once
#include <iostream>
#include <string>

using namespace std;

class Pessoa
{
public:
	Pessoa();
	~Pessoa();
	string s_nome;
	int i_idade;
};

