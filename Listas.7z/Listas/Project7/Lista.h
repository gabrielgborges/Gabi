#pragma once
#include "No.h"
class Lista
{
public:
	Lista();
	~Lista();

	No * lista, * lista_aux;
	void percorrerLista(No * lista);
	void insereFimLista(No * no);
	bool remove(No * no);
	void insereEm(int posicao); //
	int obtemTamanhoLista(); //
	bool listaVazia(); //
	void esvaziaLista(); //

protected:
	int tamanho;
};

