#pragma once
#include "No.h"
#include "Pessoa.h"
class ListaPessoas
{
public:
	ListaPessoas();
	~ListaPessoas();

	No * lista_pessoas;
	void percorrerLista(No * lista);
};

