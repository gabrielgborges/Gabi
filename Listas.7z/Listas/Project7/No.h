#pragma once
#include "Pessoa.h"
class No
{
public:
	No();
	~No();
	Pessoa * pessoa;//informacao que sera armazenada
	No * proximo; //ponteiro para o proximo n�



};

