#include "Lista.h"



Lista::Lista()
{
}


Lista::~Lista()
{
}

void Lista::percorrerLista(No * lista)
{
		lista = lista->proximo;
		if (lista != nullptr) {
			percorrerLista(lista);
		}
}

void Lista::insereFimLista(No * no)
{
	if (this->lista == nullptr) {
		this->lista = no;
	}
	else
	{
		this->lista_aux = this->lista;
		while (this->lista_aux->proximo != nullptr) {
			this->lista_aux = this->lista_aux->proximo;
		}
		this->lista_aux->proximo = no;
	}
}

void Lista::insereEm(int posicao)
{
}

int Lista::obtemTamanhoLista()
{
	this->tamanho = 0;
	lista_aux = lista;
	while (this->lista != nullptr) {

		tamanho++;
		this->lista_aux = this->lista_aux->proximo;
	}
	return tamanho;
	
}

bool Lista::listaVazia()
{
	if (this->lista == nullptr) {
		return true;
	}
	else {
		return false;
	}
}

void Lista::esvaziaLista()
{

}
