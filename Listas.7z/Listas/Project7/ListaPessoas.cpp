#include "ListaPessoas.h"



ListaPessoas::ListaPessoas()
{
}


ListaPessoas::~ListaPessoas()
{
}


