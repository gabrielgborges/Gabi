#include <iostream>
#include "No.h"
#include "Pessoa.h"
#include "ListaPessoas.h"
#include "Lista.h"

void lerlista(No * lista) {
	cout << lista << endl;
	lista = lista->proximo;
	if (lista != nullptr) {
		lerlista(lista);
	}
}

int main()
{
	ListaPessoas * lp_lista_pessoas = new ListaPessoas;
	lp_lista_pessoas->lista_pessoas->pessoa->s_nome;

	Pessoa * pessoa1; //definicao da lista

	No * n_lista_pessoas = nullptr;
	No*n_no; //declaracao do no
	No* n_lista_auxiliar;
	//definicao na lista
	pessoa1 = new Pessoa;
	pessoa1-> s_nome = "Daciolo";
	pessoa1-> i_idade = 40;
	//adicionar esta pessoa no no

	n_no = new No;
	n_no->pessoa = pessoa1;
	n_no = nullptr;
	

	//adicionar no na lista
	n_lista_pessoas = n_no;

	Pessoa * DEUX = new Pessoa;
	DEUX->s_nome = "DEUX";
	DEUX->i_idade = 0;
	No * n_no1 = new No;

	n_no1->pessoa = DEUX;
	n_no1->proximo = nullptr;

	//adicionar novo no na lista
	n_lista_pessoas->proximo = n_no1;

	Pessoa * eymael = new Pessoa;
	eymael->s_nome = "Eyeyeymael";
	eymael -> i_idade = 65;

	No * n_no2 = new No;
	n_no2->pessoa = eymael;
	n_no2->proximo = nullptr;

	 //adicionando novo n� na lista
	n_lista_pessoas->proximo->proximo = n_no2;
	

	/*percorrer a lista
	utilizaremos uma variavel auxiliar
	inicializamos a variavel aulxiliar apontando para*/
	
	//enquanto nao chegar no fim da lista
	n_lista_auxiliar = n_lista_pessoas;
	/*while (n_lista_auxiliar != nullptr)*/
		/*{
			cout << n_lista_auxiliar->pessoa->s_nome << endl;
			n_lista_auxiliar = n_lista_auxiliar->proximo;

		}
	*/
	
		lerlista(n_lista_auxiliar);
	system("pause");
    return 0;
}

